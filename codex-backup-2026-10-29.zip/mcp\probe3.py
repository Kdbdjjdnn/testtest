import json
import subprocess
import sys
import time

SCRIPT = sys.argv[1]
CALL = json.loads(sys.argv[2]) if len(sys.argv) > 2 else None

p = subprocess.Popen([sys.executable, "-u", SCRIPT], stdin=subprocess.PIPE,
                     stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                     text=True, encoding="utf-8")

nid = [0]


def send(obj):
    p.stdin.write(json.dumps(obj) + "\n")
    p.stdin.flush()


def read_until(want_id, timeout=90):
    end = time.time() + timeout
    while time.time() < end:
        line = p.stdout.readline()
        if not line:
            time.sleep(0.2)
            continue
        try:
            msg = json.loads(line)
        except Exception:
            continue
        if msg.get("id") == want_id:
            return msg
    return None


send({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {
    "protocolVersion": "2024-11-05", "capabilities": {},
    "clientInfo": {"name": "p", "version": "0"}}})
read_until(1)
send({"jsonrpc": "2.0", "method": "notifications/initialized"})

nid[0] = 2
send({"jsonrpc": "2.0", "id": 2, "method": "tools/list"})
tl = read_until(2)
print("TOOLS:")
for t in (tl["result"]["tools"] if tl else []):
    print("  -", t["name"])

if CALL:
    nid[0] = 3
    send({"jsonrpc": "2.0", "id": 3, "method": "tools/call",
          "params": {"name": CALL["name"], "arguments": CALL.get("arguments", {})}})
    res = read_until(3, 120)
    if res:
        content = res["result"]["content"]
        txt = content[0]["text"] if content else ""
        print("CALL", CALL["name"], "->")
        print(txt[:1200])
    else:
        print("no response for call")

p.terminate()
