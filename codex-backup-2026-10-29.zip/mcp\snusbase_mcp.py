#!/usr/bin/env python3
"""Snusbase MCP server (stdio).

Tools:
  snusbase_search       - main breach-database search
  snusbase_count        - count matching rows without record contents
  snusbase_combo_lookup - combolist username/password lookup
  snusbase_hash_lookup  - cracked-hash <-> plaintext lookup
  snusbase_ip_whois     - IP WHOIS / geolocation
  snusbase_domain_whois - domain RDAP/WHOIS
  snusbase_stats        - database statistics

Credentials are read from snusbase.txt next to this file:
  "activation code: sb...."
"""

import os
import sys
from typing import Any

import requests
from mcp.server.fastmcp import FastMCP

HERE = os.path.dirname(os.path.abspath(__file__))
KEY_FILE = os.path.join(HERE, "snusbase.txt")
BASE = "https://api.snusbase.com"
TIMEOUT = 60


def key() -> str:
    for ln in open(KEY_FILE, encoding="utf-8"):
        low = ln.strip().lower()
        if low.startswith("activation code:") or low.startswith("api key:"):
            return ln.split(":", 1)[1].strip()
    raise ValueError("could not parse snusbase.txt")


def post(path: str, payload: dict[str, Any]) -> dict[str, Any]:
    r = requests.post(BASE + path, json=payload,
                      headers={"Auth": key(), "Content-Type": "application/json"},
                      timeout=TIMEOUT)
    if r.status_code != 200:
        return {"error": f"HTTP {r.status_code}", "body": r.text[:400]}
    return r.json()


def render(data: dict[str, Any], limit: int = 60) -> str:
    if "error" in data:
        return f"error: {data['error']} {data.get('body', '')}"
    results = data.get("results") or {}
    rows = []
    for bucket, items in results.items():
        if isinstance(items, dict):
            items = [items]
        for it in items:
            if not isinstance(it, dict):
                rows.append(f"{bucket}: {it}")
                continue
            fields = "  ".join(f"{k}={v}" for k, v in it.items() if v not in (None, ""))
            rows.append(f"[{bucket}] {fields}")
    head = f"took={data.get('took')} size={data.get('size')} records={len(rows)}"
    body = "\n".join(rows[:limit])
    if len(rows) > limit:
        body += f"\n... and {len(rows) - limit} more (raise limit or narrow the query)"
    return head + "\n" + body


mcp = FastMCP("snusbase")


@mcp.tool()
def snusbase_stats() -> str:
    """Snusbase database statistics (row counts per table). No auth required."""
    try:
        r = requests.get(BASE + "/data/stats", timeout=TIMEOUT)
        j = r.json()
    except Exception as exc:
        return f"error: {exc}"
    rows = j.get("rows")
    tables = j.get("tables") or {}
    out = [f"total_rows={rows} tables={len(tables)}"]
    feats = (j.get("features") or {}).get("view_more") or []
    if feats:
        out.append("view_more tables: " + ", ".join(feats[:40]))
    return "\n".join(out)


@mcp.tool()
def snusbase_search(
    terms: list[str],
    types: list[str],
    wildcard: bool = False,
    group_by: str = "db",
    limit: int = 60,
) -> str:
    """Search Snusbase breach databases.

    types must be from: email, username, lastip, password, hash, name, _domain
      (note: the domain type is literally "_domain")
    terms: one or more values to search for; every type is applied to every term.
    wildcard: enable % and ? wildcards (cannot be the first character).
    group_by: "db" (default) or a field name, or "none" to disable.
    Returns raw breach rows: email, username, password, hash, salt, name, lastip, etc.
    """
    if not terms or not types:
        return "error: terms and types are required"
    allowed = {"email", "username", "lastip", "password", "hash", "name", "_domain"}
    bad = [t for t in types if t not in allowed]
    if bad:
        return f"error: invalid types {bad}; allowed: {sorted(allowed)}"
    payload: dict[str, Any] = {"terms": terms, "types": types}
    if wildcard:
        payload["wildcard"] = True
    if group_by and group_by != "none":
        payload["group_by"] = group_by
    elif group_by == "none":
        payload["group_by"] = False
    try:
        data = post("/data/search", payload)
    except Exception as exc:
        return f"error: {exc}"
    return render(data, limit)


@mcp.tool()
def snusbase_count(terms: list[str], types: list[str]) -> str:
    """Count matching rows per table without returning record contents."""
    if not terms or not types:
        return "error: terms and types are required"
    try:
        data = post("/data/count", {"terms": terms, "types": types})
    except Exception as exc:
        return f"error: {exc}"
    if "error" in data:
        return f"error: {data['error']} {data.get('body', '')}"
    results = data.get("results") or {}
    lines = [f"total_matches={data.get('size')} tables={len(results)}"]
    for k, v in sorted(results.items(), key=lambda kv: -kv[1] if isinstance(kv[1], int) else 0):
        lines.append(f"  {v:>10}  {k}")
    return "\n".join(lines[:80])


@mcp.tool()
def snusbase_combo_lookup(terms: list[str], types: list[str] | None = None, limit: int = 60) -> str:
    """Look up username/password pairs in combolist databases.

    types: "username" or "password" (which field to match terms against).
    """
    t = types or ["username"]
    try:
        data = post("/tools/combo-lookup", {"terms": terms, "types": t})
    except Exception as exc:
        return f"error: {exc}"
    return render(data, limit)


@mcp.tool()
def snusbase_hash_lookup(terms: list[str], types: list[str] | None = None, limit: int = 60) -> str:
    """Look up cracked hashes or reverse-lookup plaintext -> hash.

    types: "hash" (default; hash -> plaintext) or "password" (plaintext -> hash).
    MD5/SHA1/SHA256 etc. are supported when present in the cracked-hash DB.
    """
    t = types or ["hash"]
    try:
        data = post("/tools/hash-lookup", {"terms": terms, "types": t})
    except Exception as exc:
        return f"error: {exc}"
    return render(data, limit)


@mcp.tool()
def snusbase_ip_whois(terms: list[str], limit: int = 40) -> str:
    """WHOIS / geolocation for IP addresses: country, city, ISP, AS, proxy/hosting flags."""
    try:
        data = post("/tools/ip-whois", {"terms": terms})
    except Exception as exc:
        return f"error: {exc}"
    if "error" in data:
        return f"error: {data['error']} {data.get('body', '')}"
    results = data.get("results") or {}
    out = []
    for ip, rec in list(results.items())[:limit]:
        if isinstance(rec, dict):
            out.append(f"{ip}: {rec.get('country')} / {rec.get('city')} isp={rec.get('isp')} "
                       f"as={rec.get('as')} proxy={rec.get('proxy')} hosting={rec.get('hosting')}")
        else:
            out.append(f"{ip}: {rec}")
    return "\n".join(out)


@mcp.tool()
def snusbase_domain_whois(terms: list[str], limit: int = 10) -> str:
    """WHOIS/RDAP for domains: registrar, dates, nameservers, DNS records."""
    try:
        data = post("/tools/domain-whois", {"terms": terms})
    except Exception as exc:
        return f"error: {exc}"
    if "error" in data:
        return f"error: {data['error']} {data.get('body', '')}"
    results = data.get("results") or {}
    out = []
    for d, rec in list(results.items())[:limit]:
        if not isinstance(rec, dict):
            out.append(f"{d}: {rec}")
            continue
        date = rec.get("date") or {}
        reg = ((rec.get("registrar") or {}).get("name")) or "?"
        ns = ", ".join((rec.get("nameserver") or [])[:4])
        out.append(f"{d}: registrar={reg} created={date.get('created')} expires={date.get('expires')} ns={ns}")
    errs = data.get("errors") or []
    if errs:
        out.append("errors: " + "; ".join(errs[:5]))
    return "\n".join(out)


if __name__ == "__main__":
    try:
        mcp.run()
    except BrokenPipeError:
        sys.exit(0)
