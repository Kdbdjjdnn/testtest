# NEW MACHINE SETUP — READ THIS FIRST

You are on a fresh machine. Your job: restore the full security research
stack. This file is your complete instruction set.

## Before you start

This folder contains everything needed to restore:

```
api-keys.txt          — All credentials + service info + costs
AGENTS.md             — Behavior rules + stack documentation
env-file.txt          — The .env file (rename to .env after placing)
bugbounty-prompt.txt  — Operating prompt
opencode.json         — MCP server configuration
proxy-check.ps1       — Proxy verification script
launch-persistent.js  — Browser profile launcher
browser-profiles-README.md — Browser docs
gitignore.txt         — Renames to .gitignore
mcp/                  — MCP server scripts (dehashed, snusbase, gmail_reader)
SETUP-NEW-MACHINE.md  — This file
```

## Your tasks (do these in order)

### Task 0: Install package manager + basics

```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser -Force
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Invoke-WebRequest -Uri "https://get.scoop.sh" -OutFile "$env:TEMP\scoop.ps1"
& "$env:TEMP\scoop.ps1"
```

If scoop fails, download and install manually:
- Node.js: https://nodejs.org (LTS)
- Python: https://python.com (3.13+, check "Add to PATH")
- Git: https://git-scm.com

Verify: `node --version`, `python --version`, `git --version`

### Task 1. Create directory structure

```powershell
New-Item -ItemType Directory -Path D:\codex, D:\tools\bin, D:\tools\downloads -Force
```

Add `D:\tools\bin` to user PATH:

```powershell
$toolsPath = "D:\tools\bin"
$currentPath = [Environment]::GetEnvironmentVariable("Path", "User")
if ($currentPath -notlike "*$toolsPath*") {
    [Environment]::SetEnvironmentVariable("Path",
        "$currentPath;$toolsPath", "User")
}
```

### Task 2. Restore config files

```powershell
# From this backup folder:
Copy-Item env-file.txt D:\codex\.env
Copy-Item AGENTS.md D:\codex\AGENTS.md
Copy-Item api-keys.txt D:\codex\api-keys.txt
Copy-Item bugbounty-prompt.txt D:\codex\bugbounty-prompt.txt
Copy-Item proxy-check.ps1 D:\codex\proxy-check.ps1
Copy-Item gitignore.txt D:\codex\.gitignore
Copy-Item launch-persistent.js D:\codex\browser-profiles\launch-persistent.js
New-Item -ItemType Directory -Path D:\codex\browser-profiles\default -Force
New-Item -ItemType Directory -Path D:\codex\browser-profiles\stealth -Force

# MCP server scripts
Copy-Item mcp D:\codex\mcp -Recurse

# OpenCode config
New-Item -ItemType Directory -Path "$env:USERPROFILE\.config\opencode" -Force
Copy-Item opencode.json "$env:USERPROFILE\.config\opencode\opencode.json"
```

### Task 3. Install Python dependencies

```powershell
pip install google-auth google-auth-oauthlib google-api-python-client
```

### Task 3b. Verify Capsolver key

Capsolver needs no install — the API key is in `env-file.txt` (CAPSOLVER_API_KEY).
Verify it works after restoring the .env:

```powershell
# Load .env, then check balance
$key = (Get-Content D:\codex\.env | Select-String "CAPSOLVER_API_KEY") -replace "CAPSOLVER_API_KEY=", ""
$body = @{ clientKey = $key } | ConvertTo-Json
$r = Invoke-RestMethod -Uri "https://api.capsolver.com/getBalance" -Method Post -Body $body -ContentType "application/json"
# Should show errorId 0 and the balance (~$10)
```

### Task 4. Install npm MCP servers

```powershell
npm install -g whois-mcp
```

### Task 5. Install CLI tools

Download latest Windows releases from GitHub. Extract all .exe files
into `D:\tools\bin\`:

```powershell
# Use GitHub API to find latest releases, e.g.:
# https://api.github.com/repos/<org>/<repo>/releases/latest

# For each tool below, find the "windows_amd64" .zip asset and download it:
#   subfinder:  github.com/projectdiscovery/subfinder
#   nuclei:     github.com/projectdiscovery/nuclei
#   httpx:      github.com/projectdiscovery/httpx
#   dnsx:       github.com/projectdiscovery/dnsx
#   naabu:      github.com/projectdiscovery/naabu
#   katana:     github.com/projectdiscovery/katana
#   interactsh: github.com/projectdiscovery/interactsh
#   gau:        github.com/lc/gau
#   ffuf:       github.com/ffuf/ffuf

# Try scoop for others:
scoop install 7zip nmap sqlmap hashcat trufflehog gitleaks
```

### Task 6. Download wordlists

```powershell
Invoke-WebRequest -Uri "https://github.com/danielmiessler/SecLists/archive/refs/heads/master.zip" `
    -OutFile "D:\tools\downloads\seclists.zip"
# Extract to D:\tools\wordlists\ using 7zip
```

### Task 7. Restore subfinder config

```powershell
New-Item -ItemType Directory -Path "$env:USERPROFILE\AppData\Roaming\subfinder" -Force
```

Create `provider-config.yaml` in that folder. Get the GitHub token from
`api-keys.txt`. The file should contain the token in this format:

```yaml
github: ["<github_pat_token_here>"]
censys: []
shodan: []
chaos: []
virustotal: []
securitytrails: []
alienvault: []
bevigil: []
bufferover: []
builtwith: []
c99: []
certspotter: []
chinaz: []
crtname: []
digitalyama: []
dnsdb: []
dnsdumpster: []
dnsrepo: []
domainsproject: []
driftnet: []
fofa: []
fullhunt: []
hackertarget: []
intelx: []
leakix: []
merklemap: []
netlas: []
onyphe: []
profundis: []
pugrecon: []
quake: []
reconeer: []
redhuntlabs: []
robtex: []
rsecloud: []
subdomaincenter: []
submd: []
threatbook: []
urlscan: []
whoisxmlapi: []
windvane: []
zoomeyeapi: []
```

### Task 8. Re-authenticate Gmail API

```powershell
python D:\codex\mcp\gmail_reader.py --auth
```

Tell the user: "Sign in with caramat098@gmail.com in the browser window
that opens. Approve the permission request."

### Task 9. Verify everything works

```powershell
# 1. Test proxy rotation
powershell -File D:\codex\proxy-check.ps1

# 2. Test subfinder
subfinder -d google.com -timeout 10

# 3. Test Gmail reader
python D:\codex\mcp\gmail_reader.py --latest 1
```

### Task 10. Report

When done, give the user a status report:

- What's installed and working
- What failed or needs attention
- Any credentials that need manual re-auth
- Costs (monthly subscriptions still active)

## Common problems

- **scoop install fails** → Try winget, or download tools manually from
  GitHub releases
- **SecLists download times out** → Retry, it's a big file (~700MB)
- **Gmail auth fails** → Delete `gmail_token.json`, run `--auth` again
- **Python package fails** → Try `python -m pip install <package>` instead
- **Path issues** → Restart the terminal after installing tools so PATH updates
