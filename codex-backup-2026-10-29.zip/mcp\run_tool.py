import json
import sys

call = {"name": sys.argv[2], "arguments": json.loads(sys.argv[3]) if len(sys.argv) > 3 else {}}
sys.argv = [sys.argv[0], sys.argv[1]]
exec(open("probe3.py", encoding="utf-8").read().replace(
    'CALL = json.loads(sys.argv[2]) if len(sys.argv) > 2 else None', 'CALL = call'))
