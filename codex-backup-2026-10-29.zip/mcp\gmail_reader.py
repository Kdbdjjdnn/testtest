#!/usr/bin/env python3
"""
Gmail reader for catch-all domain verification codes.
Reads emails from caramat098@gmail.com (catch-all: anything@mail1429.com).

Usage:
  python gmail_reader.py --auth          # First-time OAuth setup (opens browser)
  python gmail_reader.py --latest [n]    # Show latest n emails (default 5)
  python gmail_reader.py --search QUERY  # Search emails
  python gmail_reader.py --code          # Extract verification codes from latest email
"""
import argparse
import json
import os
import re
import sys
from pathlib import Path

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

# Config paths
SCRIPT_DIR = Path(__file__).parent
CLIENT_SECRET = Path(r"D:\codex\client_secret_651151116909-8m0f3am98abhqfpumtu6ifkqcv2mvdbn.apps.googleusercontent.com.json")
TOKEN_FILE = SCRIPT_DIR / "gmail_token.json"

SCOPES = ["https://www.googleapis.com/auth/gmail.readonly"]


def get_credentials():
    """Get valid credentials, either from token file or via OAuth flow."""
    creds = None
    if TOKEN_FILE.exists():
        creds = Credentials.from_authorized_user_file(str(TOKEN_FILE), SCOPES)

    if creds and creds.expired and creds.refresh_token:
        creds.refresh(Request())
    elif not creds or not creds.valid:
        flow = InstalledAppFlow.from_client_secrets_file(str(CLIENT_SECRET), SCOPES)
        # Use run_local_server for desktop flow
        creds = flow.run_local_server(port=0)
        with open(TOKEN_FILE, "w") as f:
            f.write(creds.to_json())
    return creds


def get_service():
    creds = get_credentials()
    return build("gmail", "v1", credentials=creds)


def list_latest(service, n=5, query=""):
    """List latest emails, optionally filtered by query."""
    results = service.users().messages().list(
        userId="me", maxResults=n, q=query
    ).execute()
    messages = results.get("messages", [])


    emails = []
    for msg in messages:
        detail = service.users().messages().get(
            userId="me", id=msg["id"], format="full"
        ).execute()
        headers = {h["name"]: h["value"] for h in detail["payload"]["headers"]}
        snippet = detail.get("snippet", "")

        # Get body
        body = ""
        if "parts" in detail["payload"]:
            for part in detail["payload"]["parts"]:
                if part.get("mimeType") == "text/plain" and "data" in part.get("body", {}):
                    import base64
                    body = base64.urlsafe_b64decode(part["body"]["data"]).decode("utf-8", errors="ignore")
                    break

        emails.append({
            "from": headers.get("From", ""),
            "to": headers.get("To", ""),
            "subject": headers.get("Subject", ""),
            "date": headers.get("Date", ""),
            "snippet": snippet,
            "body": body[:1000] if body else "",
        })
    return emails


def extract_codes(text):
    """Extract verification codes from email text."""
    # Common patterns: 4-8 digit codes, alphanumeric codes with 6+ chars
    patterns = [
        r"\b(\d{6})\b",           # 6-digit codes
        r"\b(\d{4,8})\b",         # 4-8 digit codes
        r"\b([A-Z0-9]{6,8})\b",   # Alphanumeric uppercase codes
        r"\b([a-z0-9]{8,12})\b",  # Longer lowercase codes
        r"code[:\s]+(\w{4,12})",  # "code: XXXX" pattern
        r"Code[:\s]+(\w{4,12})",  # "Code: XXXX" pattern
    ]
    for pattern in patterns:
        matches = re.findall(pattern, text, re.IGNORECASE)
        if matches:
            return list(set(matches))[:3]
    return []


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--auth", action="store_true", help="Run OAuth setup")
    parser.add_argument("--latest", type=int, nargs="?", const=5, default=None,
                       help="Show latest emails (default 5)")
    parser.add_argument("--search", type=str, help="Gmail search query")
    parser.add_argument("--code", action="store_true", help="Extract codes from latest email")
    parser.add_argument("--to", type=str, help="Filter by recipient (e.g., test@mail1429.com)")
    args = parser.parse_args()

    if args.auth:
        get_credentials()
        print("OAuth setup complete. Token saved.")
        return

    service = get_service()

    query = ""
    if args.to:
        query = f"to:{args.to} "
    if args.search:
        query += args.search

    n = args.latest or 5
    emails = list_latest(service, n, query)

    if not emails:
        print(json.dumps({"emails": [], "message": "No emails found"}))
        return

    if args.code:
        for email in emails:
            codes = extract_codes(email["body"] or email["snippet"])
            if codes:
                print(json.dumps({
                    "subject": email["subject"],
                    "from": email["from"],
                    "to": email["to"],
                    "codes": codes,
                }, indent=2))
                return
        print(json.dumps({"codes": [], "message": "No codes found in latest emails"}))
    else:
        print(json.dumps({"emails": emails}, indent=2))


if __name__ == "__main__":
    main()
