// Persistent browser launcher for AI agent use
// Usage: node launch-persistent.js [profile-name]
//   profile-name: "default" (standard Chromium) or "stealth" (camoufox)
//
// The browser launched here keeps its cookies, localStorage, and
// fingerprints between sessions via the persistent profile dirs.

const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const PROFILES = {
  default: {
    dir: 'D:\\codex\\browser-profiles\\default',
    type: 'chromium',
  },
  stealth: {
    dir: 'D:\\codex\\browser-profiles\\stealth',
    // camoufox for Cloudflare-protected targets
    type: 'camoufox',
  },
};

const profileName = process.argv[2] || 'default';
const profile = PROFILES[profileName];

if (!profile) {
  console.error(`Unknown profile: ${profileName}`);
  console.error(`Available: ${Object.keys(PROFILES).join(', ')}`);
  process.exit(1);
}

(async () => {
  console.log(`Launching persistent browser profile: ${profileName}`);
  console.log(`Profile dir: ${profile.dir}`);

  if (profile.type === 'camoufox') {
    const { default: Camoufox } = require('camoufox');
    const browser = await Camoufox({
      persistentContext: {
        userDataDir: profile.dir,
        headless: false,
      },
    });
    console.log('Camoufox launched. PID:', browser.process()?.pid);
    console.log('Press Ctrl+C to close.');
  } else {
    const browser = await chromium.launchPersistentContext(profile.dir, {
      headless: false,
      args: [
        '--disable-blink-features=AutomationControlled',
        '--no-first-run',
        '--no-default-browser-check',
      ],
    });
    console.log('Chromium launched with persistent profile.');
    console.log('Pages:', browser.pages().length);
  }

  // Keep alive
  process.on('SIGINT', async () => {
    console.log('Closing browser...');
    process.exit(0);
  });
})();
