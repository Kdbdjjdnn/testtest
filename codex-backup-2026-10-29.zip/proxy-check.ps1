# Webshare proxy status + rotation check
# Usage: powershell -File D:\codex\proxy-check.ps1
$headers = @{ "Authorization" = "Token $env:WEBSHARE_API_TOKEN" }
if (-not $env:WEBSHARE_API_TOKEN) {
  Get-Content D:\codex\.env | ForEach-Object {
    if ($_ -match '^([^=]+)=(.*)$') { Set-Item -Path "env:$($Matches[1])" -Value $Matches[2] }
  }
  $headers = @{ "Authorization" = "Token $env:WEBSHARE_API_TOKEN" }
}

Write-Host "=== Webshare Proxy Check ===" -ForegroundColor Cyan

# 1. Account / plan
try {
  $profile = Invoke-RestMethod -Uri "https://proxy.webshare.io/api/v2/profile/" -Headers $headers
  Write-Host "Account: $($profile.email)"
} catch { Write-Host "Auth FAILED: $($_.Exception.Message)" -ForegroundColor Red; exit 1 }

# 2. Bandwidth usage
try {
  $bw = Invoke-RestMethod -Uri "https://proxy.webshare.io/api/v2/subscription/bandwidth/" -Headers $headers
  Write-Host ("Bandwidth used: {0:N2} / {1:N2} GB" -f ($bw.total_used/1073741824), ($bw.total_limit/1073741824))
} catch { Write-Host "Bandwidth query failed: $($_.Exception.Message)" }

# 3. Rotation test - 3 requests should show different exit IPs
Write-Host "`nRotation test (3 requests):"
$proxyUrl = "http://${env:WEBSHARE_USERNAME}:${env:WEBSHARE_PASSWORD}@${env:WEBSHARE_PROXY_HOST}:${env:WEBSHARE_PROXY_PORT}"
1..3 | ForEach-Object {
  $ip = curl.exe -s --proxy $proxyUrl "http://ifconfig.me" --max-time 20 2>$null
  if ($ip -match '^\d+\.\d+') { Write-Host "  Request ${_}: $ip" } else { Write-Host "  Request ${_}: FAILED" }
}
