import json
import subprocess
import sys
import time

SCRIPT = sys.argv[1]
p = subprocess.Popen([sys.executable, "-u", SCRIPT], stdin=subprocess.PIPE,
                     stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                     text=True, encoding="utf-8")

msg = {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {
    "protocolVersion": "2024-11-05", "capabilities": {},
    "clientInfo": {"name": "p", "version": "0"}}}
p.stdin.write(json.dumps(msg) + "\n")
p.stdin.flush()
time.sleep(3)
p.terminate()
out = p.stdout.read()
err = p.stderr.read()
print("STDOUT:", out[:800])
print("STDERR:", err[:2000])
