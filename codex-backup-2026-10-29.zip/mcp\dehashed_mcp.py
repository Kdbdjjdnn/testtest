#!/usr/bin/env python3
"""DeHashed v2 MCP server (stdio).

Tools:
  dehashed_search  - run a breach search query (costs 1 credit)
  dehashed_balance - account balance / connectivity check

Credentials are read from dehashed.txt next to this file:
  line 1: account email
  line 3: API key
"""

import os
import sys
from typing import Any

import requests
from mcp.server.fastmcp import FastMCP

HERE = os.path.dirname(os.path.abspath(__file__))
KEY_FILE = os.path.join(HERE, "dehashed.txt")
URL = "https://api.dehashed.com/v2/search"
TIMEOUT = 45


def credentials() -> tuple[str, str]:
    lines = [l.strip() for l in open(KEY_FILE, encoding="utf-8") if l.strip()]
    email = lines[0]
    key = ""
    for ln in lines:
        if "@" not in ln and len(ln) > 20:
            key = ln
            break
    if not key:
        raise ValueError("could not parse dehashed.txt")
    return email, key


def search(query: str, page: int = 1, size: int = 100,
           wildcard: bool = False, regex: bool = False, de_dupe: bool = True) -> dict[str, Any]:
    _, key = credentials()
    r = requests.post(
        URL,
        json={"query": query, "page": page, "size": size,
              "wildcard": wildcard, "regex": regex, "de_dupe": de_dupe},
        headers={"Dehashed-Api-Key": key, "Content-Type": "application/json"},
        timeout=TIMEOUT,
    )
    if r.status_code != 200:
        return {"error": f"HTTP {r.status_code}", "body": r.text[:400]}
    return r.json()


mcp = FastMCP("dehashed")


@mcp.tool()
def dehashed_balance() -> str:
    """Check DeHashed API connectivity and remaining search credits."""
    try:
        data = search("email:test@gmail.com", size=1)
    except Exception as exc:
        return f"error: {exc}"
    if "error" in data:
        return f"error: {data['error']} {data.get('body', '')}"
    return f"connected. balance={data.get('balance')} credits (control query returned {data.get('total')} total)"


@mcp.tool()
def dehashed_search(
    query: str,
    size: int = 100,
    page: int = 1,
    wildcard: bool = False,
    regex: bool = False,
) -> str:
    """Search DeHashed breach databases. Costs 1 credit per call, max ~5 req/s, page*size <= 50000.

    Query syntax: field:value with AND, e.g.
      "email:someone@example.com"
      "domain:example.com"
      "username:jdoe"
      "phone:+15551234567"
      "name:John Doe"
      "ip_address:1.2.3.4"
      "password:secret"
      "hashed_password:<hash>"
      "vin:..."
      "database_name:Adobe"  (may be rejected on v2)
    Fields returned per entry: email, username, name, address, phone, ip_address,
    password, hashed_password, url, vin, database_name.
    """
    if size > 10000:
        return "error: size max is 10000"
    try:
        data = search(query, page=page, size=size, wildcard=wildcard, regex=regex)
    except Exception as exc:
        return f"error: {exc}"
    if "error" in data:
        return f"error: {data['error']} {data.get('body', '')}"

    entries = data.get("entries") or []
    out = [f"balance={data.get('balance')} total={data.get('total')} returned={len(entries)} took={data.get('took')}"]
    for i, e in enumerate(entries, 1):
        out.append(f"\n[{i}] db={e.get('database_name')} id={e.get('id')}")
        for f in ("email", "username", "name", "address", "phone", "ip_address",
                  "password", "hashed_password", "url", "vin"):
            v = e.get(f)
            if v:
                out.append(f"    {f:16} {', '.join(str(x) for x in v) if isinstance(v, list) else v}")
    return "\n".join(out)


if __name__ == "__main__":
    try:
        mcp.run()
    except BrokenPipeError:
        sys.exit(0)
