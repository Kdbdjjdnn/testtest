# Persistent Browser Profiles

AI browser sessions that keep their identity (cookies, localStorage,
fingerprints) between restarts.

## Profiles

| Profile | Browser | Use for |
|---------|---------|---------|
| `default` | Chromium (Playwright) | General browsing, testing, scraping |
| `stealth` | Camoufox | Cloudflare-protected targets, anti-bot bypass |

## Launch persistent browser

```powershell
# Standard Chromium with persistent profile
node D:\codex\browser-profiles\launch-persistent.js default

# Stealth Camoufox with persistent profile (for Cloudflare targets)
node D:\codex\browser-profiles\launch-persistent.js stealth
```

## Direct Playwright usage (from AI agent scripts)

```javascript
const { chromium } = require('playwright');

// Persistent context — same identity every time
const browser = await chromium.launchPersistentContext(
  'D:\\codex\\browser-profiles\\default',
  { headless: false }
);
```

## Connect to YOUR real Chrome (existing sessions)

1. Close Chrome completely
2. Launch Chrome with remote debugging:
   `"C:\Program Files\Google\Chrome\Application\chrome.exe" --remote-debugging-port=9222`
3. AI connects:
```javascript
const { chromium } = require('playwright');
const browser = await chromium.connectOverCDP('http://localhost:9222');
```

## Notes

- Profile dirs: `D:\codex\browser-profiles\default` and `...\stealth`
- Cookies/sessions survive browser restarts
- Delete a profile dir to reset identity
- Don't commit profile dirs to git (contains cookies) — already gitignored
