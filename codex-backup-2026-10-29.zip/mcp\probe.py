import json
import subprocess
import sys

SCRIPT = sys.argv[1]

proc = subprocess.Popen([sys.executable, "-u", SCRIPT], stdin=subprocess.PIPE,
                        stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                        encoding="utf-8")


def send(obj):
    proc.stdin.write(json.dumps(obj) + "\n")
    proc.stdin.flush()


def read():
    line = proc.stdout.readline()
    return json.loads(line) if line.strip() else None


send({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {
    "protocolVersion": "2024-11-05",
    "capabilities": {},
    "clientInfo": {"name": "probe", "version": "0"},
}})
init = read()
print("server:", init["result"]["serverInfo"])

send({"jsonrpc": "2.0", "method": "notifications/initialized"})
send({"jsonrpc": "2.0", "id": 2, "method": "tools/list"})
tl = read()
print("tools:")
for t in tl["result"]["tools"]:
    print("  -", t["name"], "|", t.get("description", "")[:70])

proc.terminate()
